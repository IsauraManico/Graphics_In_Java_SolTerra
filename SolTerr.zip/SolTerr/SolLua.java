/* 


    Autor:Isaura Manico
*/

import javax.swing.*;
import java.awt.*;


public class SolLua  extends JFrame //implements Runnable
{
    
  
    
    Astros astros = new Astros(0,100,0,100,100,130);
    
    private Thread thread = new Thread();

    int i;
    


    public SolLua()
    {
        i = 0;

        astros.setSol(new ImageIcon(getClass().getResource("sol.jpg")).getImage());
        astros.setLua( new ImageIcon(getClass().getResource("lua.jpg")).getImage());
        astros.setTerra( new ImageIcon(getClass().getResource("terra.jpg")).getImage());
       // 
       // thread.start();

    }

  
    public void paint(Graphics g)
    {

        super.paint(g);

       
        

     
            while(true)
            {
                    g.setColor(Color.yellow); //seleciona a cor amarela do nome do sol
                    g.setFont(new Font("Calibra", Font.ITALIC, 20) );
                    g.drawString("Sol", 500, 290);
                    g.drawString("IsauraM", 10, 200);


                    //Planeta Terra-----------------



        ////			Cor da trajetoria
                    g.setColor(Color.white);
        //
        ////			Trajetoria
                    g.drawOval(350,260,300,200);

        ////	   Calculo do movimento
                    astros.setX_terra((int)(Math.sin((3.14 * (i+50))/180 )* astros.getTam_terra()*1.5));
                    astros.setY_terra( (int)(Math.cos((3.14 * (i+50))/180 )* astros.getTam_terra()));

        ////        Cor do nome do planeta vermelha
                    g.setColor(Color.blue);
        ////	    Imagem do planeta terra
                    //g.drawImage(terra,x_terra + dx_terra, y_terra + dy_terra,10,10,this);
                    g.drawImage(astros.getTerra(),astros.getX_terra() + astros.getDx_terra(), astros.getY_terra() + astros.getDy_terra(),20,20,this);
        ////	    Texto com o nome do planeta
                    g.drawString("Terra", astros.getX_terra()+ astros.getDx_terra(), astros.getY_terra() + astros.getDy_terra());
        //
        //
        ////			-------


                    //Lua-----------------

        //			Cor da trajetoria
                    g.setColor(Color.white);

        //			Trajetoria
                    g.drawOval(310,220,380,270);

        //			Calculo do movimento
                    astros.setX_lua((int)(Math.sin((3.14 * (i+40))/180 )* astros.getTam_lua()*1.5));
                    astros.setY_lua( (int)(Math.cos((3.14 * (i+40))/180 )* astros.getTam_lua()));

        //			Cor do planeta azul
                    g.setColor(Color.pink);
        //			Desenho do planeta Venus
                    //g.fillOval(x_ven + dx_ven , y_ven + dy_ven ,20,20);
                    g.drawImage(astros.getLua(),astros.getX_lua() + astros.getDx_lua() , astros.getY_lua() + astros.getDy_lua(),20,20,this);
        //			Texto com o nome do planeta
                    g.drawString("Lua", astros.getX_lua() + astros.getDx_lua(), astros.getY_lua() + astros.getDy_lua());


        //			-------

                    //Atrasa o tempo
                    try
                    {
                        Thread.sleep(20);
                    }
                    catch(InterruptedException e)
                    {
                        System.out.println("Error: nao Funcionou!");

                    }

                    g.drawImage(astros.getSol(),485,295,130,130,this);//Carrega a imagem do sol com tamanho 130x130

                    i++;


                    if (i == 100000)
                    {
                         break;
                    }
                    
                     try
                        {
                            Thread.sleep(10);
                        } 
                        catch (InterruptedException ex) 
                        {
                            System.out.println("Error");
                        }




                  // Apaga o desenho da terra anterior
                    g.setColor(Color.black);
                    g.fillRect(astros.getX_terra() + astros.getDx_terra() , astros.getY_terra() + astros.getDy_terra(),20,20);
                    g.drawString("Terra", astros.getX_terra() + astros.getDx_terra(), astros.getY_terra() + astros.getDy_terra());


        //			Apaga o desenho da Lua anterior
                    g.setColor(Color.black);
                    g.fillRect(astros.getX_lua() + astros.getDx_lua() , astros.getY_lua() + astros.getDy_lua(),20,20);
                    g.drawString("Lua", astros.getX_lua() + astros.getDx_lua(), astros.getY_lua() + astros.getDy_lua());

                    }

        }


    
    
}
