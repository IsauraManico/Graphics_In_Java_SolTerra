
import java.awt.Image;



/**
 *
 * @author isaura
 */
public class Astros 
{
    
    
    
    private int x_terra,y_terra;  //Terra
    private int x_lua, y_lua; //lua
    
    private int tam_terra;
    private int tam_lua;
    
    
    private static final int posx = 500;
   // private static final int posx2 = 400;
    private static final int posy = 350;
    //private static final int posy2 = 300;
    
    
    
    private int dx_terra = posx; //posicao x inicial do circulo de terra
    private int dx_lua = posx; //posicao x inicial do circulo de lua
    
    
    private int dy_terra = posy;
    private int dy_lua = posy;
    
    
    private Image terra;
    private Image lua;
    private  Image sol;
    
    

    public Astros(int x_terra, int y_terra, int x_lua, 
            int y_lua,  int tam_terra, int tam_lua) 
    {
        this.x_terra = x_terra;
        this.y_terra = y_terra;
        
        this.x_lua = x_lua;
        this.y_lua = y_lua;
       
        this.tam_terra = tam_terra;
        this.tam_lua = tam_lua;
       
       
    }
    
    
    
    public Image getTerra() 
    {
        return terra;
    }

    public void setTerra(Image terra) 
    {
        this.terra = terra;
    }

    public Image getLua() 
    {
        return lua;
    }

    public void setLua(Image lua)
    {
        this.lua = lua;
    }

    public Image getSol() 
    {
        return sol;
    }

    public void setSol(Image sol)
    {
        this.sol = sol;
    }
    
    public int getX_terra()
    {
        return x_terra;
    }

    public void setX_terra(int x_terra) 
    {
        this.x_terra = x_terra;
    }

    public int getY_terra()
    {
        return y_terra;
    }

    public void setY_terra(int y_terra)
    {
        this.y_terra = y_terra;
    }

    public int getDx_terra() 
    {
        return dx_terra;
    }

    public void setDx_terra(int dx_terra) 
    {
        this.dx_terra = dx_terra;
    }

    public int getDy_terra() 
    {
        return dy_terra;
    }

    public void setDy_terra(int dy_terra) 
    {
        this.dy_terra = dy_terra;
    }

    public int getX_lua()
    {
        return x_lua;
    }

    public void setX_lua(int x_lua)
    {
        this.x_lua = x_lua;
    }

    public int getY_lua() 
    {
        return y_lua;
    }

    public void setY_lua(int y_lua)
    {
        this.y_lua = y_lua;
    }

    public int getDx_lua() 
    {
        return dx_lua;
    }

    public void setDx_lua(int dx_lua) 
    {
        this.dx_lua = dx_lua;
    }

    public int getDy_lua() 
    {
        return dy_lua;
    }

    public void setDy_lua(int dy_lua) 
    {
        this.dy_lua = dy_lua;
    }

    public int getTam_terra() 
    {
        return tam_terra;
    }

    public void setTam_terra(int tam_terra) 
    {
        this.tam_terra = tam_terra;
    }

    public int getTam_lua()
    {
        return tam_lua;
    }

    public void setTam_lua(int tam_lua)
    {
        this.tam_lua = tam_lua;
    }

  


    
    
    
    
    
    
    
    
    
    
    
    
}
