
import java.awt.Color;
import javax.swing.JFrame;


/**
 *
 * @author isaura
 */
public class Principal 
{
      public static void main(String[] args)
    {
        //Cria um objeto p
        SolLua p = new SolLua();
        
        
        p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        p.getContentPane().setBackground( Color.black );
        p.setSize(1024,800); // Define o Tamanho do Frame como x = 1024 e y = 800

        p.setVisible(true);

    }

    
}
